#ifndef Vuelos_h
#define Vuelos_h

class Vuelo{
  private:
    int pasajeros;
    string numVuelo;
    string sentido;
    Avion avion;
    Tiempo tiempo;
    string destino;

  public:
    Vuelo();
    Vuelo(int pasajeros,string numVuelo,string sentido,Avion avion, Tiempo tiempo, string destino);
    void setPasajeros(int pasajeros);
    void setNumVuelo(string numVuelo);
    void setSentido(string sentido);
    void setAvion(Avion avion);
    void setTiempo(Tiempo tiempo);
    void setDestino(string destino);

    int getPasajeros();
    string getNumVuelo();
    string getSentido();
    Avion getAvion();
    Tiempo getTiempo();
    string getDestino();
};




Vuelo::Vuelo(){
  pasajeros = 0;
  numVuelo = "";
  sentido = "";
  Avion avion1;
  avion = avion1;
  Tiempo tiempo1;
  tiempo = tiempo1;
  destino = "";
}

Vuelo::Vuelo(int pasajeros, string numVuelo, string sentido, Avion avion, Tiempo tiempo, string destino){
  this-> pasajeros = pasajeros;
  this-> numVuelo = numVuelo;
  this-> sentido = sentido;
  this-> avion = avion;
  this-> tiempo = tiempo;
  this-> destino = destino;
}




void Vuelo::setPasajeros(int pasajeros){
  this-> pasajeros = pasajeros;
}

void Vuelo::setNumVuelo(string numVuelo){
  this-> numVuelo = numVuelo;
}

void Vuelo::setSentido(string sentido){
  this-> sentido = sentido;
}

void Vuelo::setAvion(Avion avion){
  this-> avion = avion;
}

void Vuelo::setTiempo(Tiempo tiempo){
  this-> tiempo = tiempo;
}

void Vuelo::setDestino(string destino){
  this->destino = destino;
}





int Vuelo::getPasajeros(){
  return pasajeros;
}

string Vuelo::getNumVuelo(){
  return numVuelo;
}

string Vuelo::getSentido(){
  return sentido;
}

Avion Vuelo::getAvion(){
  return avion;
}

Tiempo Vuelo::getTiempo(){
  return tiempo;
}

string Vuelo::getDestino(){
  return destino;
}

#endif


