#ifndef proyecto_h
#define proyecto_h

class aviones {
    public:

    private:
    aviones();
    string modelo;
    int asientos;
    int asientosOcupados;
    float rendimiento;
    float capacidadTanque;
    float kilometraje;
    float capacidadEquipaje;
    float equipajeActual;
    float gasolinaActual;

    string getModelo;
    int getAsientos;
    int getAsientosOcupados;
    float getRendimiento;
    float getCapacidadTanque;
    float getKilometraje;
    float getCapacidadEquipaje;
    float getEquipajeActual;
    float getGasolinaActual;

    void setModelo(string modelo);
    void setAsientos(int asientos);
    void setAsientosOcupados(int asientosOcupados);
    void setRendimiento(float rendimiento);
    void setCapacidadTanque(float capacidadTanque);
    void setEquipajeActual(float equipajeActual);
    void setGasolinaActual(float gasolinaActual);

    void llenaTanque();
    void imprimeAviones();
    
};

class vuelos {
    public:

    private:
    vuelos();
    int puertaDeSalida;
    string numVuelo;
    string transporte;
    string destino;
    string partida;
    avion marca;
    string latitud;
    string longitud;
    tiempo llegada;
    string estadoVuelo;

    int getPuertaDeSalida;
    string getNumVuelo;
    string getTransporte;
    string getDestino;
    string getPartida;
    string getLatitud;
    string getLongitud;
    string getEstadoVuelo

    void setPuertaDeSalida(int puertaDeSalida);
    void setNumVuelo(string numVuelo);
    void setTransporte(string transporte);
    void setDestino(string destino);
    void setPartida(string partida);
    void setMarca(string marca);
    void setLatitud(string latitud);
    void setLongitud(string longitud);
    void setLlegada(string llegada);


    void imprimeVuelos();

};


//////

aviones::aviones(string modelo, int asientos, int asientosOcupados, float rendimiento, float capacidadTanque, float kilometraje, float capacidadEquipaje, float equipajeActual, float gasolinaActual){
    this -> modelo = modelo;
    this -> asientos = asientos;
    this -> asientosOcupados = asientosOcupados;
    this -> rendimiento = rendimiento;
    this -> capacidadTanque = capacidadTanque;
    this -> kilometraje = kilometraje;
    this -> capacidadEquipaje = capacidadEquipaje;
    this -> equipajeActual = equipajeActual;
    this -> gasolinaActual = gasolinaActual;
}
vuelos::vuelos(int puertaDeSalida, string numVuelo, string transporte,  string destino, string partida, string latitud, string longitud, string llegada){
    this -> puertaDeSalida = puertaDeSalida;
    this -> numVuelo = numVuelo;
    this -> transporte = transporte;
    this -> destino = destino;
    this -> partida = partida;
    this -> latitud = latitud;
    this -> longitud = longitud;
    this -> llegada = llegada;
}

////
 avion::avion(){
    modelo = "";
    asientosOcupados = 0;
    rendimientos = 0;
    capacidadTanque = 0;
    kilometraje = 0;
    capacidadEquipaje = 0;
    equipajeActual = 0;
    gasolinaActual = 0;
 }

 vuelos::vuelos(){
    puertaDeSalida = "";
    numVuelo = "";
    transporte = "";
    destino = "";
    partido = "";
    latitud = "";
    longitud = "";
 }

 ////

string aviones::getModelo(){
     return modelo;
 }

string aviones::getAsientos(){
     return asientos;
 }

string aviones::getAsientosOcupados(){
     return asientosOcupados;
 }

string aviones::getRendimiento(){
     return rendimiento;
 }
 
string aviones::getCapacidadTanque(){
     return capacidadTanque;
 }

string aviones::getKilometraje(){
     return kilometraje;
 }

string aviones::getCapacidadEquipaje(){
     return capacidadEquipaje;
 }
 
string aviones::getEquipajeActual(){
     return equipajeActual;
 }

string aviones::getGasolinaActual(){
     return gasolinaActual;
 }
 
 //--
string vuelos::getPuertoDeSalida(){
     return peurtoDeSalida;
 }

string vuelos::getNumVuelo(){
     return numVuelo;
 }

string vuelos::getTransporte(){
     return transporte;
 }

string vuelos::getDestino(){
     return destino;
 }

string vuelos::getPartida(){
     return partida;
 }

string vuelos::getLatitud(){
     return latitud;
 }

string vuelos::getLongitud(){
     return longitud;
 }

string vuelos::getLlegada(){
     return llegada;
 }

////

void aviones::llenaTanque(){
    cout << "Faltan " << capacidadTanque-gasolinaActual << "litros para tanque lleno"<<endl;
    gasolinaActual = capacidadTanque;
    cout << "Tanque lleno" <<endl;
}

void aviones::imprimeAviones(){
    cout << "Modelo: " << getModelo <<endl;
    cout << "Asientos: " << getAsientos <<endl;
    cout << "Asientos Ocupados: " << getAsientosOcupados <<endl;
    cout << "Rendimiento: " << getRendimiento <<endl;
    cout << "Capacidad Tanque: " << getCapacidadTanque<<endl;
    cout << "Kilometraje: " << getKilometraje <<endl;
    cout << "Capacidad Equipaje: " << getCapacidadEquipaje << "kg" <<endl;
    cout << "Equipaje Actual: " << getEquipajeActual << "kg" <<endl;
    cout << "Gasolina Actual: " << getGasolinaActual <<endl;
}

void vuelos::imprimeVuelos(){
    cout << "Puerta de salida: " << getPuertaDeSalida <<endl;
    cout << "Numero de vuelo: " << getNumVuelo <<endl;
    cout << "Transporte: " << getTransporte <<endl;
    cout << "Destino: " << getDestino <<endl;
    cout << "Partida: " << getPartida <<endl;
    cout << "Latitud: " << getLatitud <<endl;
    cout << "Longitud: " << getLongitud <<endl;
    cout << "Llegada: " << getLlegada <<endl;
}
#endif 