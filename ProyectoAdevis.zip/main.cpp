#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

#include "Avion.h"
#include "Tiempo.h"
#include "Vuelos.h"

int reng = 0;

Tiempo TiempoHora(string tiempo_str, string hora_str){
  int ano,mes,dia,hora,minuto;
  ano = stoi(tiempo_str.substr(0,4));
  mes = stoi(tiempo_str.substr(5,7));
  dia = stoi(tiempo_str.substr(8,10));
  hora = stoi(hora_str.substr(0,2));
  minuto = stoi(hora_str.substr(3,5));
  Tiempo f(dia,mes,ano,hora,minuto);
  return f;
}

int ContadorTiempos(Vuelo vuelos[]){
  Tiempo tiempo1;
  int contador = 0;
  for (int i = 0; i < reng; i++){
    if (!(vuelos[i].getTiempo().getAno() == tiempo1.getAno() && vuelos[i].getTiempo().getMes() == tiempo1.getMes() && vuelos[i].getTiempo().getDia() == tiempo1.getDia() )){
      tiempo1 = vuelos[i].getTiempo();
      contador++;
    }
  }
  return contador;
}

void TiemposTotales(Vuelo vuelos[],Tiempo tiempos[]){
  Tiempo tiempo1;
  int dia = 0;
  for (int i = 0; i < reng; i++){
    if(!(vuelos[i].getTiempo().getAno() == tiempo1.getAno() && vuelos[i].getTiempo().getMes() == tiempo1.getMes() && vuelos[i].getTiempo().getDia() == tiempo1.getDia() )){
      tiempo1 = vuelos[i].getTiempo();
      tiempos[dia] = tiempo1;
      dia++;
    }
  }
}

int HoraSaturada(Tiempo v, Vuelo vuelos[]) {
  int ano = v.getAno();
  int mes = v.getMes();
  int dia = v.getDia();

  int horas[24];
  for(int i = 0; i < 24; i++) {
    horas[i] = 0;
  }

  int i = 0;

  while(!(vuelos[i].getTiempo().getAno() == ano && vuelos[i].getTiempo().getMes() == mes && vuelos[i].getTiempo().getDia() == dia )) {
    i++;
  }

    while(vuelos[i].getTiempo().getAno() == ano && vuelos[i].getTiempo().getMes() == mes && vuelos[i].getTiempo().getDia() == dia ) {
      horas[vuelos[i].getTiempo().getHora()] += 1;
      i++;
  }

  int mayor = 0;
  int iMayor = 0;
  for(int i = 0; i < 24; i++) {
    if(mayor < horas[i]) {
      mayor = horas[i];
      iMayor = i;
    }
  }
  return iMayor;
}
int ContadorSentido(string sentido, Vuelo vuelos[]){
  int contador = 0;
  for (int i = 0; i < reng; i++) {
    if(vuelos[i].getSentido() == sentido) {
      contador++;
    }
  }
  return contador;
}

void SentidoTotales(string sentido, Vuelo vuelos[], Vuelo vuelosSentido[]){
  int contador = 0;
  for (int i = 0; i < reng; i++){
    if(vuelos[i].getSentido() == sentido) {
      vuelosSentido[contador] = vuelos[i];
      contador++;
    }
  }
}


void PromHora(int total, int tiempos, Vuelo vuelos[], float horas[]) {
  for(int i = 0; i < 24; i++) {
    horas[i] = 0;
  }

  for(int i = 0; i < total; i++) {
    horas[vuelos[i].getTiempo().getHora()] += 1;
  }

  for(int i = 0; i < 24; i++) {
    horas[i] = horas[i]/tiempos;
  }
}

void NumeroAerolineas(vector<string> &aerolineas, Vuelo vuelos[]) {
  bool boolean;
  for(int i = 0; i < reng; i++)
  {
    boolean = false;
    for(int j = 0; j < aerolineas.size(); j++) {
      if(aerolineas[j] == vuelos[i].getAvion().getAerolinea()) {
        boolean = true;
      }
    }
    if(!boolean) {
      aerolineas.push_back(vuelos[i].getAvion().getAerolinea());
    }
  }
}

void vuelosHora(Vuelo vuelos[], int reng){
  int horasLlegadas[24],horasSalidas[24];
  for (int i = 0; i < 24; i++){
    horasLlegadas[i] = 0;
    horasSalidas[i] = 0;
  }
  for (int i = 0; i < reng; i++){
    if (vuelos[i].getSentido() == "A"){
      horasLlegadas[vuelos[i].getTiempo().getHora()]++;
    } else {
      horasSalidas[vuelos[i].getTiempo().getHora()]++;
    }
  }
  for (int i = 0; i < 24; i++){
    cout << "El numero de vuelos a las " << i << " horas son " << horasLlegadas[i] + horasSalidas[i]<< " . De los cuales " << horasLlegadas[i] << " son llegadas y " << horasSalidas[i] << " son salidas." << endl; 
  }
}

int NumeroPasajeros(Tiempo v, Vuelo vuelos[]) {
  int suma = 0;
  int ano = v.getAno();
  int mes = v.getMes();
  int dia = v.getDia();

  int i = 0;
  while(!(vuelos[i].getTiempo().getAno() == ano && vuelos[i].getTiempo().getMes() == mes && vuelos[i].getTiempo().getDia() == dia)) {
    i++;
  }

  while(vuelos[i].getTiempo().getAno() == ano && vuelos[i].getTiempo().getMes() == mes && vuelos[i].getTiempo().getDia() == dia) {
    suma += vuelos[i].getPasajeros();
    i++;
  }
  return suma;
}

float CapacidadUtilizada(Tiempo v, Vuelo vuelos[]) {
  float SP = 0;
  float SC = 0;
  float total = 0;
  int ano = v.getAno();
  int mes = v.getMes();
  int dia = v.getDia();

  int i = 0;
  while(!(vuelos[i].getTiempo().getAno() == ano && vuelos[i].getTiempo().getMes() == mes && vuelos[i].getTiempo().getDia() == dia)) {
    i++;
  }

  while(vuelos[i].getTiempo().getAno() == ano && vuelos[i].getTiempo().getMes() == mes && vuelos[i].getTiempo().getDia() == dia) {
    SP += vuelos[i].getPasajeros();
    SC += vuelos[i].getAvion().getAsientosMax();
    i++;
  }
  total = SP/SC;
  return total*100;
}

int main() {
  string datos[9];
  ifstream archivo;

  archivo.open("datos_vuelos.txt");

  while( archivo >> datos[0] >> datos[1] >> datos[2] >> datos[3] >> datos[4] >> datos[5] >> datos[6] >> datos[7] >> datos[8] ) {
    reng++;
  }

  archivo.close();


  Vuelo vuelos[reng];
  int i = 0;
  archivo.open("datos_vuelos.txt");
  Tiempo Tiempo_temp;
  while ( archivo >> datos[0] >> datos[1] >> datos[2] >> datos[3] >> datos[4] >> datos[5] >> datos[6] >> datos[7] >> datos[8] ) {
    
    Tiempo_temp = TiempoHora(datos[0], datos[1]);
    vuelos[i] = Vuelo(stoi(datos[7]),datos[2], datos[3],Avion(datos[6],stoi(datos[8]),datos[4]), Tiempo_temp, datos[5] );
    i++;
  }

  archivo.close();





  // 1
  Tiempo tiempos[ContadorTiempos(vuelos)];
  TiemposTotales(vuelos, tiempos);
  for(int i = 0; i < ContadorTiempos(vuelos); i++) {
    cout << "La hora con la mayor cantidad de vuelos el " << tiempos[i].getDia() << " de" << tiempos[i].getMes() << " del"  << tiempos[i].getAno() << " es " << HoraSaturada(tiempos[i], vuelos) << endl;
  }

  cout << endl;


  // 2 y 3
  vuelosHora(vuelos,reng);
  
  int entrada, salida; 
  entrada = ContadorSentido("A", vuelos);
  salida = ContadorSentido("S", vuelos);

  Vuelo vuelosEntrada[entrada];
  SentidoTotales("A", vuelos, vuelosEntrada);
  float horasEntrada[24];
  PromHora(entrada, ContadorTiempos(vuelos), vuelosEntrada, horasEntrada);

  Vuelo vuelosSalida[salida];
  SentidoTotales("S", vuelos, vuelosSalida);
  float horasSalida[24];
  PromHora(salida, ContadorTiempos(vuelos), vuelosSalida, horasSalida);
  /*
  for(int i = 1; i < 25; i++) { //cambie de i=0;i < 25
    cout << "La hora " << i << " tiene un total de " << horasEntrada[i] << " llegadas y " << horasSalida[i] << " salidas promedio." << endl;
  }

  cout << endl; */
  
  // 4
  vector<string> aerolineas;
  NumeroAerolineas(aerolineas, vuelos);
  sort(aerolineas.begin(), aerolineas.end());
  int cantAerolineaEntrada[aerolineas.size()];
  for(int i = 0; i < aerolineas.size(); i++) {
    cantAerolineaEntrada[i] = 0;
  }

  int cantAerolineaSalida[aerolineas.size()];
  for(int i = 0; i < aerolineas.size(); i++) {
    cantAerolineaSalida[i] = 0;
  }

  for(int i = 0; i < aerolineas.size(); i++) {
    for(int j = 0; j < entrada; j++) {
      if(aerolineas[i] == vuelosEntrada[j].getAvion().getAerolinea()) {
        cantAerolineaEntrada[i] += 1;
      }
    }
  }

  for(int i = 0; i < aerolineas.size(); i++) {
    for(int j = 0; j < salida; j++) {
      if(aerolineas[i] == vuelosSalida[j].getAvion().getAerolinea()) {
        cantAerolineaSalida[i] += 1;
      }
    }
  }

  for(int j = 0; j < aerolineas.size(); j++) {
    cout << "La aerolinea " << aerolineas[j] <<" tiene " << cantAerolineaEntrada[j]+cantAerolineaSalida[j] << " vuelos, de los cuales tiene un total de " << cantAerolineaEntrada[j] << " llegadas y " << cantAerolineaSalida[j] << " salidas." << endl;
  }

  cout << endl;


  
  // 5
  for(int i = 0; i < ContadorTiempos(vuelos); i++) {
    cout << "El numero de pasajeros atendidos e " << tiempos[i].getDia() << " en " << tiempos[i].getMes() << " en el "  << tiempos[i].getAno() << " es de " << NumeroPasajeros(tiempos[i], vuelos) << endl;
  }

  cout << endl;


  // 6
  for(int i = 0; i < ContadorTiempos(vuelos); i++) {
    cout << "El porcentaje promedio de capacidad utilizada en " << tiempos[i].getDia() << " en " << tiempos[i].getMes() << " el "  << tiempos[i].getAno() << " es " << CapacidadUtilizada(tiempos[i], vuelos) << "%" << endl;
  }
  
  /*for(int i = 0;i < reng;i++){
    cout << vuelos[i].getTiempo().getMinuto()<<endl;
  }
  return 0;*/
}



