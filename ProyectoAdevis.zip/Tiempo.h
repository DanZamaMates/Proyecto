#ifndef Tiempo_h
#define Tiempo_h

class Tiempo {
	private:
		int minuto;
    int hora;
    int dia;
		int mes;
		int ano;
	public:
    Tiempo();
    Tiempo(int minuto, int hora,int dia, int mes, int ano);

    void setMinuto(int minuto);
    void setHora(int hora);
    void setDia(int dia);
    void setMes(int mes);
    void setAno(int ano);

    int getMinuto();
    int getHora();
    int getDia();
    int getMes();
		int getAno();
};

Tiempo::Tiempo(){
  minuto = 0;
  hora = 0;
  dia = 1;
  mes = 1;
  ano = 2019;
}

Tiempo::Tiempo(int dia, int mes, int ano, int hora, int minuto){
  this->minuto = minuto;
  this->hora = hora;
  this->dia = dia;
  this->mes = mes;
  this->ano =ano;
}



void Tiempo::setMinuto(int minuto){
  this->minuto = minuto;
}
void Tiempo::setHora(int hora){
  this->hora = hora;
}
void Tiempo::setDia(int dia){
  this->dia = dia;
}
void Tiempo::setMes(int mes){
  this->mes = mes;
}
void Tiempo::setAno(int ano){
  this->ano =ano;
}



int Tiempo::getMinuto(){
  return minuto;
}
int Tiempo::getHora(){
  return hora;
}
int Tiempo::getDia(){
  return dia;
}
int Tiempo::getMes(){
  return mes;
}
int Tiempo::getAno(){
  return ano;
}

#endif