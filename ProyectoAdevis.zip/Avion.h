#ifndef Avion_h
#define Avion_h

class Avion {
  private:
  int asientosMax;
  string modeloAvion;
  string aerolinea;

  public:
  Avion();
  Avion(string modeloAvion, int asientosMax, string aerolinea);

  void setModeloAvion(string modeloAvion);
  void setAsientosMax(int asientosMax);
  void setAerolinea(string aerolinea);

  string getModeloAvion();
  int getAsientosMax();
  string getAerolinea();
};

Avion::Avion(){
  modeloAvion = "";
  asientosMax = 0;
  aerolinea = "";
}

Avion::Avion(string modeloAvion, int asientosMax,string aerolinea){
  this -> modeloAvion = modeloAvion;
  this -> asientosMax = asientosMax;
  this -> aerolinea = aerolinea;

}

void Avion::setAsientosMax(int asientosMax){
  this -> asientosMax = asientosMax;
}

void Avion::setModeloAvion(string modeloAvion){
  this -> modeloAvion = modeloAvion;
}

void Avion::setAerolinea(string aerolinea){
  this -> aerolinea = aerolinea;
}

int Avion::getAsientosMax(){
  return asientosMax;
}

string Avion::getModeloAvion(){
  return modeloAvion;
}

string Avion::getAerolinea(){
  return aerolinea;
}

#endif

